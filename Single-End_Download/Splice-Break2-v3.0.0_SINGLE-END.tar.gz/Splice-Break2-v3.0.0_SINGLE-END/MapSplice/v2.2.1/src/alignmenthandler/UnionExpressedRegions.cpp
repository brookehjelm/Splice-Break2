#include "UnionExpressedRegions.h"

UnionExpressedRegions::UnionExpressedRegions() : m_unioned_region_length(0)
{
}